# Crude Tier 2 Schedule Calendar

This is a public iCalendar (.ics) file containing the St. Albert Crude Tier 2 game schedule.

## How to publish this calendar using GitHub

1. Go to https://github.com/new and create a new repository.
2. Name it something like `crude-tier2-schedule`.
3. Upload the `Crude_Tier2_Schedule.ics` file to the repository.
4. Once uploaded, click on the `.ics` file and then click the "Raw" button to get a direct link.
5. Copy that URL and use it to subscribe in your calendar app (Google Calendar, Apple Calendar, etc.)

## Example (Google Calendar)
- Open Google Calendar.
- On the left, click the "+" next to "Other calendars" → "From URL".
- Paste the GitHub Raw URL.
- Click "Add Calendar".

Enjoy!